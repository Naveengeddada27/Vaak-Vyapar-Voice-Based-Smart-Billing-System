// Product database for Vaak Vyapaar
// Each product has: id, name, aliases (for voice matching), price, category, unit

const products = [
  { id: 1,  name: 'Milk',       aliases: ['milk', 'doodh', 'milk packet', 'milk packets'],        price: 25,  category: 'Dairy',      unit: 'packet' },
  { id: 2,  name: 'Bread',      aliases: ['bread', 'pav', 'bread loaf'],                          price: 40,  category: 'Bakery',     unit: 'piece' },
  { id: 3,  name: 'Biscuit',    aliases: ['biscuit', 'biscuits', 'cookie', 'cookies'],             price: 10,  category: 'Snacks',     unit: 'packet' },
  { id: 4,  name: 'Rice',       aliases: ['rice', 'chawal', 'rice bag'],                           price: 60,  category: 'Grains',     unit: 'kg' },
  { id: 5,  name: 'Sugar',      aliases: ['sugar', 'cheeni', 'shakkar'],                           price: 45,  category: 'Grains',     unit: 'kg' },
  { id: 6,  name: 'Tea',        aliases: ['tea', 'chai', 'tea packet', 'tea powder'],              price: 20,  category: 'Beverages',  unit: 'packet' },
  { id: 7,  name: 'Coffee',     aliases: ['coffee', 'coffee powder'],                              price: 30,  category: 'Beverages',  unit: 'packet' },
  { id: 8,  name: 'Oil',        aliases: ['oil', 'tel', 'cooking oil', 'refined oil'],             price: 120, category: 'Cooking',    unit: 'litre' },
  { id: 9,  name: 'Dal',        aliases: ['dal', 'daal', 'lentil', 'lentils', 'toor dal'],         price: 80,  category: 'Grains',     unit: 'kg' },
  { id: 10, name: 'Soap',       aliases: ['soap', 'sabun', 'bath soap'],                          price: 35,  category: 'Personal',   unit: 'piece' },
  { id: 11, name: 'Shampoo',    aliases: ['shampoo'],                                              price: 90,  category: 'Personal',   unit: 'bottle' },
  { id: 12, name: 'Toothpaste', aliases: ['toothpaste', 'paste', 'tooth paste'],                   price: 50,  category: 'Personal',   unit: 'piece' },
  { id: 13, name: 'Butter',     aliases: ['butter', 'makhan'],                                     price: 55,  category: 'Dairy',      unit: 'packet' },
  { id: 14, name: 'Cheese',     aliases: ['cheese', 'paneer slice', 'cheese slice'],               price: 70,  category: 'Dairy',      unit: 'packet' },
  { id: 15, name: 'Eggs',       aliases: ['egg', 'eggs', 'anda', 'ande'],                          price: 8,   category: 'Dairy',      unit: 'piece' },
  { id: 16, name: 'Chips',      aliases: ['chips', 'potato chips', 'crisps', 'wafers'],            price: 20,  category: 'Snacks',     unit: 'packet' },
  { id: 17, name: 'Juice',      aliases: ['juice', 'fruit juice'],                                 price: 30,  category: 'Beverages',  unit: 'packet' },
  { id: 18, name: 'Water',      aliases: ['water', 'paani', 'water bottle', 'mineral water'],      price: 15,  category: 'Beverages',  unit: 'bottle' },
  { id: 19, name: 'Salt',       aliases: ['salt', 'namak'],                                        price: 20,  category: 'Cooking',    unit: 'kg' },
  { id: 20, name: 'Flour',      aliases: ['flour', 'atta', 'wheat flour', 'maida'],                price: 45,  category: 'Grains',     unit: 'kg' },
  { id: 21, name: 'Maggi',      aliases: ['maggi', 'noodles', 'instant noodles'],                   price: 14,  category: 'Snacks',     unit: 'packet' },
  { id: 22, name: 'Curd',       aliases: ['curd', 'dahi', 'yogurt', 'yoghurt'],                    price: 30,  category: 'Dairy',      unit: 'packet' },
  { id: 23, name: 'Ghee',       aliases: ['ghee', 'desi ghee', 'clarified butter'],                price: 250, category: 'Cooking',    unit: 'litre' },
  { id: 24, name: 'Detergent',  aliases: ['detergent', 'washing powder', 'surf', 'tide'],          price: 65,  category: 'Household',  unit: 'packet' },
  { id: 25, name: 'Matchbox',   aliases: ['matchbox', 'match box', 'matches'],                     price: 5,   category: 'Household',  unit: 'piece' },
];

export function findProduct(query) {
  const q = query.toLowerCase().trim();
  // Exact alias match first
  for (const product of products) {
    if (product.aliases.includes(q)) return product;
  }
  // Partial match
  for (const product of products) {
    for (const alias of product.aliases) {
      if (alias.includes(q) || q.includes(alias)) return product;
    }
  }
  // Fuzzy: check if any word in query matches an alias
  const words = q.split(/\s+/);
  for (const product of products) {
    for (const alias of product.aliases) {
      for (const word of words) {
        if (word.length > 2 && alias.includes(word)) return product;
      }
    }
  }
  return null;
}

export function getAllProducts() {
  return [...products];
}

export default products;

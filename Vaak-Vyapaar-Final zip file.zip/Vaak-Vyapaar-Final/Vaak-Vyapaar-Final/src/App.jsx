import React, { useState, useCallback, useRef, useEffect } from 'react';
import Header from './components/Header';
import LoginPage from './components/LoginPage';
import MicButton from './components/MicButton';
import ManualEntry from './components/ManualEntry';
import BillTable from './components/BillTable';
import Invoice from './components/Invoice';
import Toast from './components/Toast';
import ProductCatalog from './components/ProductCatalog';
import ProductManager from './components/ProductManager';
import CommandHistory from './components/CommandHistory';
import useSpeechRecognition from './hooks/useSpeechRecognition';
import { parseCommand } from './utils/nlpParser';
import { api, setToken, getToken } from './utils/api';

let toastCounter = 0;
let historyCounter = 0;

function speak(text) {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 1.1; u.lang = 'en-IN';
    window.speechSynthesis.speak(u);
  }
}

export default function App() {
  const [user, setUser] = useState(null);
  const [loginError, setLoginError] = useState('');
  const [authLoading, setAuthLoading] = useState(true);
  const [products, setProducts] = useState([]);
  const [billItems, setBillItems] = useState([]);
  const [showInvoice, setShowInvoice] = useState(false);
  const [toasts, setToasts] = useState([]);
  const [interimText, setInterimText] = useState('');
  const [commandHistory, setCommandHistory] = useState([]);
  const [activeTab, setActiveTab] = useState('billing');
  const newItemTimers = useRef({});

  // Check existing session on mount
  useEffect(() => {
    if (getToken()) {
      api.me().then(data => { setUser(data.user); loadProducts(); })
        .catch(() => { setToken(null); })
        .finally(() => setAuthLoading(false));
    } else { setAuthLoading(false); }
  }, []);

  const loadProducts = async () => {
    try { const data = await api.getProducts(); setProducts(data); } catch (e) { console.error(e); }
  };

  const handleLogin = async (username, password) => {
    try {
      setLoginError('');
      const data = await api.login(username, password);
      setToken(data.token);
      setUser(data.user);
      await loadProducts();
    } catch (e) { setLoginError(e.message || 'Login failed'); }
  };

  const handleLogout = async () => {
    try { await api.logout(); } catch (e) { /* ignore */ }
    setToken(null); setUser(null); setBillItems([]); setCommandHistory([]);
  };

  const addToast = useCallback((message, type = 'success', icon = '✓') => {
    const id = ++toastCounter;
    setToasts(prev => [...prev.slice(-3), { id, message, type, icon }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3000);
  }, []);

  const addHistory = useCallback((text, success, icon) => {
    const id = ++historyCounter;
    setCommandHistory(prev => [{ id, text, success, icon }, ...prev].slice(0, 15));
  }, []);

  const handleAddItem = useCallback((product, quantity) => {
    setBillItems(prev => {
      const existing = prev.find(i => i.id === product.id);
      if (existing) return prev.map(i => i.id === product.id ? { ...i, quantity: i.quantity + quantity, isNew: true } : i);
      return [...prev, { ...product, quantity, isNew: true }];
    });
    if (newItemTimers.current[product.id]) clearTimeout(newItemTimers.current[product.id]);
    newItemTimers.current[product.id] = setTimeout(() => {
      setBillItems(prev => prev.map(i => i.id === product.id ? { ...i, isNew: false } : i));
    }, 1600);
    const msg = `Added ${quantity} ${product.name}`;
    addToast(msg, 'success', '➕'); addHistory(msg, true, '🛒'); speak(msg);
  }, [addToast, addHistory]);

  const handleRemoveItem = useCallback((product, quantity) => {
    setBillItems(prev => {
      const existing = prev.find(i => i.id === product.id);
      if (!existing) {
        addToast(`${product.name} not in bill`, 'error', '⚠️'); speak(`${product.name} is not in the bill`);
        return prev;
      }
      const newQty = existing.quantity - quantity;
      if (newQty <= 0) { addToast(`Removed ${product.name}`, 'info', '🗑'); speak(`Removed ${product.name}`); return prev.filter(i => i.id !== product.id); }
      addToast(`Removed ${quantity} ${product.name}`, 'info', '➖'); speak(`Removed ${quantity} ${product.name}`);
      return prev.map(i => i.id === product.id ? { ...i, quantity: newQty } : i);
    });
  }, [addToast]);

  const handleVoiceResult = useCallback((text) => {
    setInterimText('');
    const result = parseCommand(text, products);
    switch (result.action) {
      case 'add':
        if (result.error) { addToast(result.error, 'error', '❓'); addHistory(`"${text}" — ${result.error}`, false, '❓'); speak(result.error); }
        else handleAddItem(result.product, result.quantity);
        break;
      case 'remove':
        if (result.error) { addToast(result.error, 'error', '❓'); addHistory(`"${text}" — ${result.error}`, false, '❓'); speak(result.error); }
        else handleRemoveItem(result.product, result.quantity);
        break;
      case 'generate':
        if (billItems.length === 0) { addToast('Bill is empty', 'error', '📋'); speak('Bill is empty'); }
        else { setShowInvoice(true); addToast('Invoice generated!', 'success', '📄'); addHistory('Generated invoice', true, '📄'); speak('Invoice generated'); }
        break;
      case 'clear':
        setBillItems([]); addToast('Bill cleared', 'info', '🧹'); addHistory('Bill cleared', true, '🧹'); speak('Bill cleared');
        break;
      default:
        addToast(`Couldn't understand: "${text}"`, 'error', '❓'); addHistory(`"${text}" — not understood`, false, '❓'); speak("Sorry, I didn't understand that");
    }
  }, [billItems.length, products, handleAddItem, handleRemoveItem, addToast, addHistory]);

  const { isListening, isSupported, toggleListening } = useSpeechRecognition({ onResult: handleVoiceResult, onInterim: useCallback(t => setInterimText(t), []) });

  const handleUpdateQty = useCallback((id, delta) => {
    setBillItems(prev => { const item = prev.find(i => i.id === id); if (!item) return prev; const nq = item.quantity + delta; return nq <= 0 ? prev.filter(i => i.id !== id) : prev.map(i => i.id === id ? { ...i, quantity: nq } : i); });
  }, []);

  const handleSaveInvoice = async (invoiceData) => {
    try { await api.saveBill(invoiceData); addToast('Bill saved to database', 'success', '💾'); } catch (e) { console.error(e); }
  };

  const handleAddProduct = async (data) => {
    try { const p = await api.addProduct(data); setProducts(prev => [...prev, p]); addToast(`Added product: ${p.name}`, 'success', '📦'); } catch (e) { addToast(e.message, 'error', '❌'); }
  };
  const handleUpdateProduct = async (id, data) => {
    try { const p = await api.updateProduct(id, data); setProducts(prev => prev.map(x => x.id === id ? p : x)); addToast(`Updated: ${p.name}`, 'success', '✏️'); } catch (e) { addToast(e.message, 'error', '❌'); }
  };
  const handleDeleteProduct = async (id) => {
    try { await api.deleteProduct(id); setProducts(prev => prev.filter(x => x.id !== id)); addToast('Product removed', 'info', '🗑'); } catch (e) { addToast(e.message, 'error', '❌'); }
  };

  const subtotal = billItems.reduce((s, i) => s + i.price * i.quantity, 0);
  const tax = Math.round(subtotal * 0.05);
  const total = subtotal + tax;
  const itemCount = billItems.reduce((s, i) => s + i.quantity, 0);

  const quickCommands = [
    { label: '🥛 2 Milk', cmd: '2 milk' }, { label: '🍞 1 Bread', cmd: '1 bread' },
    { label: '🍪 3 Biscuit', cmd: '3 biscuit' }, { label: '❌ Remove milk', cmd: 'remove 1 milk' },
    { label: '📄 Generate Bill', cmd: 'generate bill' }, { label: '🧹 Clear', cmd: 'clear bill' },
  ];

  if (authLoading) return <div className="login-page"><div style={{ color: 'var(--text-muted)', fontSize: '1.1rem' }}>Loading...</div></div>;
  if (!user) return <LoginPage onLogin={handleLogin} error={loginError} />;

  return (
    <>
      <Header user={user} onLogout={handleLogout} activeTab={activeTab} onTabChange={setActiveTab} />

      {activeTab === 'billing' ? (
        <div className="app-layout">
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div className="card">
              <div className="card__header">
                <span className="card__title"><span className="card__title-icon">🎤</span> Voice Control</span>
                <span className="card__badge">{isListening ? '● LIVE' : 'Ready'}</span>
              </div>
              <div className="card__body">
                <MicButton isListening={isListening} isSupported={isSupported} onToggle={toggleListening} interimText={interimText} />
                <div className="quick-commands">
                  {quickCommands.map(qc => (<button key={qc.cmd} className="quick-cmd" onClick={() => handleVoiceResult(qc.cmd)}>{qc.label}</button>))}
                </div>
              </div>
            </div>

            <div className="card">
              <div className="card__header">
                <span className="card__title"><span className="card__title-icon">⌨️</span> Manual Entry</span>
                <span className="card__badge">Type to add</span>
              </div>
              <div className="card__body">
                <ManualEntry products={products} onAddItem={handleAddItem} />
              </div>
            </div>

            <div className="card">
              <div className="card__header">
                <span className="card__title"><span className="card__title-icon">📜</span> Command Log</span>
                <span className="card__badge">{commandHistory.length}</span>
              </div>
              <div className="card__body">
                {commandHistory.length ? <CommandHistory history={commandHistory} /> : (
                  <div className="bill-empty" style={{ padding: '1.5rem' }}><span style={{ fontSize: '1.5rem' }}>💬</span><div style={{ marginTop: '0.5rem', fontSize: '0.82rem' }}>Commands appear here</div></div>
                )}
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div className="card" style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
              <div className="card__header">
                <span className="card__title"><span className="card__title-icon">🧾</span> Current Bill</span>
                {itemCount > 0 && <span className="items-badge">{itemCount} items</span>}
              </div>
              <div className="card__body" style={{ flex: 1 }}>
                <BillTable items={billItems} onUpdateQty={handleUpdateQty} onRemove={(id) => setBillItems(prev => prev.filter(i => i.id !== id))} />
              </div>
              {billItems.length > 0 && (
                <div className="bill-footer">
                  <div className="bill-footer__row"><span>Subtotal</span><span>₹{subtotal}</span></div>
                  <div className="bill-footer__row"><span>GST (5%)</span><span>₹{tax}</span></div>
                  <div className="bill-footer__row bill-footer__row--total"><span>Total</span><span>₹{total}</span></div>
                  <div className="bill-footer__actions">
                    <button className="btn btn--primary" onClick={() => setShowInvoice(true)}>📄 Generate Invoice</button>
                    <button className="btn btn--danger" onClick={() => { setBillItems([]); addToast('Bill cleared', 'info', '🧹'); }}>🧹 Clear</button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="app-layout" style={{ gridTemplateColumns: '1fr' }}>
          <div className="card">
            <div className="card__header">
              <span className="card__title"><span className="card__title-icon">📦</span> Product Management</span>
            </div>
            <div className="card__body">
              <ProductManager products={products} onAdd={handleAddProduct} onUpdate={handleUpdateProduct} onDelete={handleDeleteProduct} />
            </div>
          </div>
        </div>
      )}

      <Toast toasts={toasts} />
      {showInvoice && <Invoice items={billItems} onClose={() => setShowInvoice(false)} onSave={handleSaveInvoice} />}
    </>
  );
}

// NLP Parser for voice commands — works with dynamic product list from DB

const numberWords = {
  'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4,
  'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9,
  'ten': 10, 'eleven': 11, 'twelve': 12, 'thirteen': 13,
  'fourteen': 14, 'fifteen': 15, 'sixteen': 16, 'seventeen': 17,
  'eighteen': 18, 'nineteen': 19, 'twenty': 20,
  'a': 1, 'an': 1,
};

function wordToNumber(word) {
  const lower = word.toLowerCase();
  if (numberWords[lower] !== undefined) return numberWords[lower];
  const parsed = parseInt(lower, 10);
  return isNaN(parsed) ? null : parsed;
}

const addKeywords = ['add', 'put', 'include', 'give', 'want', 'need', 'please'];
const removeKeywords = ['remove', 'delete', 'cancel', 'take out', 'minus', 'subtract', 'hatao', 'hata do'];
const generateKeywords = ['generate', 'print', 'show bill', 'final bill', 'total', 'checkout', 'bill generate', 'generate bill', 'print bill', 'bill banao', 'bill bana do'];
const clearKeywords = ['clear', 'reset', 'clear bill', 'new bill', 'start over', 'fresh', 'naya bill'];
const fillers = ['of', 'the', 'some', 'me', 'packets', 'packet', 'pieces', 'piece', 'bottles', 'bottle', 'bags', 'bag', 'boxes', 'box', 'kg', 'litre', 'litres', 'liter', 'liters', 'kilo', 'kilos'];

function findProductInList(query, products) {
  const q = query.toLowerCase().trim();
  for (const p of products) {
    const aliases = Array.isArray(p.aliases) ? p.aliases : JSON.parse(p.aliases || '[]');
    if (aliases.includes(q) || p.name.toLowerCase() === q) return p;
  }
  for (const p of products) {
    const aliases = Array.isArray(p.aliases) ? p.aliases : JSON.parse(p.aliases || '[]');
    for (const alias of aliases) {
      if (alias.includes(q) || q.includes(alias)) return p;
    }
  }
  const words = q.split(/\s+/);
  for (const p of products) {
    const aliases = Array.isArray(p.aliases) ? p.aliases : JSON.parse(p.aliases || '[]');
    for (const alias of aliases) {
      for (const word of words) {
        if (word.length > 2 && alias.includes(word)) return p;
      }
    }
  }
  return null;
}

export function parseCommand(text, products = []) {
  if (!text || typeof text !== 'string') return { action: 'unknown', raw: text };
  const raw = text.trim();
  const lower = raw.toLowerCase();

  for (const kw of generateKeywords) { if (lower.includes(kw)) return { action: 'generate', raw }; }
  for (const kw of clearKeywords) { if (lower.includes(kw)) return { action: 'clear', raw }; }

  let isRemove = false;
  let cleanedText = lower;
  for (const kw of removeKeywords) {
    if (lower.includes(kw)) { isRemove = true; cleanedText = lower.replace(new RegExp(kw, 'gi'), '').trim(); break; }
  }
  if (!isRemove) {
    for (const kw of addKeywords) { cleanedText = cleanedText.replace(new RegExp(`\\b${kw}\\b`, 'gi'), '').trim(); }
  }

  let tokens = cleanedText.split(/\s+/);
  let quantity = null, quantityIndex = -1;
  for (let i = 0; i < tokens.length; i++) {
    const num = wordToNumber(tokens[i]);
    if (num !== null) { quantity = num; quantityIndex = i; break; }
  }
  if (quantityIndex >= 0) tokens.splice(quantityIndex, 1);
  tokens = tokens.filter(t => !fillers.includes(t.toLowerCase()) && t.length > 0);
  const productQuery = tokens.join(' ').trim();

  if (!productQuery) return { action: 'unknown', raw, error: 'Could not identify product' };

  const product = findProductInList(productQuery, products);
  if (!product) return { action: isRemove ? 'remove' : 'add', raw, productQuery, error: `Product "${productQuery}" not found` };

  return { action: isRemove ? 'remove' : 'add', raw, product, quantity: quantity || 1 };
}

export default parseCommand;

// API helper with auth token management

let token = localStorage.getItem('vaak_token') || null;

export function setToken(t) {
  token = t;
  if (t) localStorage.setItem('vaak_token', t);
  else localStorage.removeItem('vaak_token');
}

export function getToken() {
  return token;
}

async function apiFetch(url, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...options.headers };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const res = await fetch(url, { ...options, headers });
  if (res.status === 401) {
    setToken(null);
    window.location.reload();
    throw new Error('Session expired');
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(err.error || 'Request failed');
  }
  return res.json();
}

export const api = {
  login: (username, password) => apiFetch('/api/login', { method: 'POST', body: JSON.stringify({ username, password }) }),
  logout: () => apiFetch('/api/logout', { method: 'POST' }),
  me: () => apiFetch('/api/me'),
  getProducts: () => apiFetch('/api/products'),
  addProduct: (data) => apiFetch('/api/products', { method: 'POST', body: JSON.stringify(data) }),
  updateProduct: (id, data) => apiFetch(`/api/products/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteProduct: (id) => apiFetch(`/api/products/${id}`, { method: 'DELETE' }),
  saveBill: (data) => apiFetch('/api/bills', { method: 'POST', body: JSON.stringify(data) }),
  getBills: () => apiFetch('/api/bills'),
};

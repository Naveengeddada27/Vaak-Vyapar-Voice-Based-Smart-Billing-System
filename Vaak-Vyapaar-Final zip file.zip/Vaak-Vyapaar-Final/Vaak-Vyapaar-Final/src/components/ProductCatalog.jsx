import React from 'react';
import { getAllProducts } from '../data/products';

export default function ProductCatalog() {
  const products = getAllProducts();
  return (
    <div className="catalog">
      {products.map((p) => (
        <span key={p.id} className="catalog__tag">
          {p.name}<span className="catalog__price">₹{p.price}</span>
        </span>
      ))}
    </div>
  );
}

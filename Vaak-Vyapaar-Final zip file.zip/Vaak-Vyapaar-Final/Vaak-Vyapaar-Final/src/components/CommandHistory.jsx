import React from 'react';

export default function CommandHistory({ history }) {
  if (!history.length) return null;
  return (
    <div className="history">
      {history.map((item) => (
        <div key={item.id} className="history-item">
          <span className="history-item__icon">{item.icon}</span>
          <span className="history-item__text">{item.text}</span>
          <span className={`history-item__status history-item__status--${item.success ? 'success' : 'error'}`}>
            {item.success ? 'Done' : 'Failed'}
          </span>
        </div>
      ))}
    </div>
  );
}

import React, { useState } from 'react';

export default function ProductManager({ products, onAdd, onUpdate, onDelete }) {
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({ name: '', price: '', category: 'General', unit: 'piece', aliases: '' });

  const resetForm = () => { setForm({ name: '', price: '', category: 'General', unit: 'piece', aliases: '' }); setEditId(null); setShowForm(false); };

  const handleEdit = (p) => {
    const aliases = Array.isArray(p.aliases) ? p.aliases : JSON.parse(p.aliases || '[]');
    setForm({ name: p.name, price: String(p.price), category: p.category, unit: p.unit, aliases: aliases.join(', ') });
    setEditId(p.id);
    setShowForm(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      name: form.name,
      price: parseFloat(form.price),
      category: form.category,
      unit: form.unit,
      aliases: form.aliases.split(',').map(a => a.trim().toLowerCase()).filter(Boolean),
    };
    if (editId) { onUpdate(editId, data); } else { onAdd(data); }
    resetForm();
  };

  return (
    <div className="product-mgr">
      <div className="product-mgr__header">
        <span>{products.length} products</span>
        <button className="btn btn--primary" style={{ padding: '0.4rem 1rem', fontSize: '0.78rem' }} onClick={() => { resetForm(); setShowForm(!showForm); }}>
          {showForm ? '✕ Cancel' : '+ Add Product'}
        </button>
      </div>

      {showForm && (
        <form className="product-mgr__form" onSubmit={handleSubmit}>
          <div className="product-mgr__grid">
            <div className="login-field">
              <label className="login-label">Name</label>
              <input className="login-input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
            </div>
            <div className="login-field">
              <label className="login-label">Price (₹)</label>
              <input className="login-input" type="number" step="0.5" min="0" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} required />
            </div>
            <div className="login-field">
              <label className="login-label">Category</label>
              <input className="login-input" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} />
            </div>
            <div className="login-field">
              <label className="login-label">Unit</label>
              <input className="login-input" value={form.unit} onChange={e => setForm({ ...form, unit: e.target.value })} />
            </div>
          </div>
          <div className="login-field">
            <label className="login-label">Aliases (comma-separated)</label>
            <input className="login-input" placeholder="milk, doodh, milk packet" value={form.aliases} onChange={e => setForm({ ...form, aliases: e.target.value })} />
          </div>
          <button className="btn btn--primary" type="submit" style={{ marginTop: '0.5rem' }}>
            {editId ? '✓ Update Product' : '+ Add Product'}
          </button>
        </form>
      )}

      <div className="product-mgr__list">
        {products.map(p => (
          <div key={p.id} className="product-mgr__item">
            <div className="product-mgr__info">
              <span className="product-mgr__name">{p.name}</span>
              <span className="product-mgr__meta">₹{p.price} / {p.unit} · {p.category}</span>
            </div>
            <div className="product-mgr__actions">
              <button className="bill-table__qty-btn" onClick={() => handleEdit(p)} title="Edit">✎</button>
              <button className="bill-table__qty-btn" onClick={() => onDelete(p.id)} title="Delete" style={{ color: 'var(--danger)' }}>✕</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

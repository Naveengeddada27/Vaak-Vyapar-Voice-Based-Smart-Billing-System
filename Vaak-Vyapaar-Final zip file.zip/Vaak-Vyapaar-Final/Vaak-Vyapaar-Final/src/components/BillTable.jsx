import React from 'react';

export default function BillTable({ items, onUpdateQty, onRemove }) {
  if (items.length === 0) {
    return (
      <div className="bill-empty">
        <span className="bill-empty__icon">🛒</span>
        No items yet
        <div className="bill-empty__hint">Say "2 milk" or "add 3 bread" to start</div>
      </div>
    );
  }

  return (
    <table className="bill-table">
      <thead>
        <tr>
          <th>Item</th>
          <th>Qty</th>
          <th>Price</th>
          <th>Subtotal</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        {items.map((item) => (
          <tr key={item.id} className={item.isNew ? 'bill-row--new' : ''}>
            <td>
              <span className="bill-table__name">{item.name}</span>
              <span className="bill-table__unit">/ {item.unit}</span>
            </td>
            <td>
              <span className="bill-table__qty">
                <button
                  className="bill-table__qty-btn"
                  onClick={() => onUpdateQty(item.id, -1)}
                  aria-label="Decrease quantity"
                >−</button>
                <span>{item.quantity}</span>
                <button
                  className="bill-table__qty-btn"
                  onClick={() => onUpdateQty(item.id, 1)}
                  aria-label="Increase quantity"
                >+</button>
              </span>
            </td>
            <td className="bill-table__price">₹{item.price}</td>
            <td className="bill-table__subtotal">₹{item.price * item.quantity}</td>
            <td>
              <button
                className="bill-table__remove"
                onClick={() => onRemove(item.id)}
                aria-label={`Remove ${item.name}`}
              >✕</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

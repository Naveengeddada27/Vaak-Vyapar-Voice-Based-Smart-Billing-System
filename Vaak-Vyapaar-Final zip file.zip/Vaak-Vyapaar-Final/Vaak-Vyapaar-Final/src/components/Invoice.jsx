import React, { useRef } from 'react';

export default function Invoice({ items, onClose, onSave }) {
  const saved = useRef(false);
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const tax = Math.round(subtotal * 0.05);
  const total = subtotal + tax;
  const now = new Date();
  const invoiceNo = `VV-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}-${String(Math.floor(Math.random() * 9000) + 1000)}`;

  // Auto-save to database once
  if (!saved.current && onSave) {
    saved.current = true;
    onSave({ invoice_no: invoiceNo, items: items.map(i => ({ name: i.name, qty: i.quantity, price: i.price })), subtotal, tax, total });
  }

  return (
    <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="invoice" id="invoice-modal">
        <div className="invoice__header">
          <div className="invoice__logo">Vaak Vyapaar</div>
          <div className="invoice__tagline">Voice-Powered Smart Billing</div>
          <div className="invoice__meta">
            <span>Invoice: {invoiceNo}</span>
            <span>{now.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })} · {now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</span>
          </div>
        </div>
        <div className="invoice__body">
          <table className="invoice__table">
            <thead><tr><th>#</th><th>Item</th><th>Qty</th><th>Price</th><th>Amount</th></tr></thead>
            <tbody>
              {items.map((item, i) => (
                <tr key={item.id}>
                  <td style={{ color: 'var(--text-muted)' }}>{i + 1}</td>
                  <td>{item.name}</td><td>{item.quantity}</td>
                  <td>₹{item.price}</td><td>₹{item.price * item.quantity}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="invoice__totals">
            <div className="invoice__totals-row"><span>Subtotal</span><span>₹{subtotal}</span></div>
            <div className="invoice__totals-row"><span>GST (5%)</span><span>₹{tax}</span></div>
            <div className="invoice__totals-row invoice__totals-row--grand"><span>Total</span><span>₹{total}</span></div>
          </div>
        </div>
        <div className="invoice__footer">
          <span className="invoice__thankyou">Thank you for shopping! 🙏</span>
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <button className="btn btn--ghost" onClick={() => window.print()}>🖨 Print</button>
            <button className="btn btn--primary" onClick={onClose}>✓ Done</button>
          </div>
        </div>
      </div>
    </div>
  );
}

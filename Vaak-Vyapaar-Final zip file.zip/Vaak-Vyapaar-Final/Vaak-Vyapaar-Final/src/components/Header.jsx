import React from 'react';

export default function Header({ user, onLogout, activeTab, onTabChange }) {
  return (
    <header className="header">
      <div className="header__brand">
        <div className="header__logo">V</div>
        <div>
          <div className="header__title">Vaak Vyapaar</div>
          <div className="header__subtitle">Voice-Powered Billing</div>
        </div>
      </div>
      {user && (
        <nav className="header__tabs">
          <button className={`header__tab ${activeTab === 'billing' ? 'header__tab--active' : ''}`} onClick={() => onTabChange('billing')}>🧾 Billing</button>
          <button className={`header__tab ${activeTab === 'products' ? 'header__tab--active' : ''}`} onClick={() => onTabChange('products')}>📦 Products</button>
        </nav>
      )}
      {user ? (
        <div className="header__user">
          <span className="header__user-name">👤 {user.name}</span>
          <button className="btn btn--ghost" style={{ padding: '0.35rem 0.8rem', fontSize: '0.75rem' }} onClick={onLogout}>Logout</button>
        </div>
      ) : (
        <div className="header__status"><span className="header__dot"></span>System Ready</div>
      )}
    </header>
  );
}

import React, { useState, useRef, useEffect } from 'react';

export default function ManualEntry({ products, onAddItem }) {
  const [query, setQuery] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [suggestions, setSuggestions] = useState([]);
  const [selectedIdx, setSelectedIdx] = useState(-1);
  const inputRef = useRef(null);

  useEffect(() => {
    if (!query.trim()) { setSuggestions([]); return; }
    const q = query.toLowerCase();
    const matches = products.filter(p => {
      if (p.name.toLowerCase().includes(q)) return true;
      const aliases = Array.isArray(p.aliases) ? p.aliases : JSON.parse(p.aliases || '[]');
      return aliases.some(a => a.includes(q));
    }).slice(0, 6);
    setSuggestions(matches);
    setSelectedIdx(-1);
  }, [query, products]);

  const handleSelect = (product) => {
    onAddItem(product, quantity);
    setQuery('');
    setQuantity(1);
    setSuggestions([]);
    inputRef.current?.focus();
  };

  const handleKeyDown = (e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIdx(i => Math.min(i + 1, suggestions.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIdx(i => Math.max(i - 1, -1));
    } else if (e.key === 'Enter' && selectedIdx >= 0) {
      e.preventDefault();
      handleSelect(suggestions[selectedIdx]);
    }
  };

  return (
    <div className="manual-entry">
      <div className="manual-entry__row">
        <div className="manual-entry__qty-wrap">
          <label className="manual-entry__label">Qty</label>
          <input
            className="manual-entry__qty"
            type="number"
            min="1"
            max="999"
            value={quantity}
            onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
          />
        </div>
        <div className="manual-entry__search-wrap">
          <label className="manual-entry__label">Search Product</label>
          <input
            ref={inputRef}
            id="manual-search"
            className="manual-entry__input"
            type="text"
            placeholder="Type product name..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            autoComplete="off"
          />
          {suggestions.length > 0 && (
            <div className="manual-entry__dropdown">
              {suggestions.map((p, i) => (
                <button
                  key={p.id}
                  className={`manual-entry__option ${i === selectedIdx ? 'manual-entry__option--active' : ''}`}
                  onClick={() => handleSelect(p)}
                  onMouseEnter={() => setSelectedIdx(i)}
                >
                  <span className="manual-entry__option-name">{p.name}</span>
                  <span className="manual-entry__option-meta">₹{p.price} / {p.unit}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

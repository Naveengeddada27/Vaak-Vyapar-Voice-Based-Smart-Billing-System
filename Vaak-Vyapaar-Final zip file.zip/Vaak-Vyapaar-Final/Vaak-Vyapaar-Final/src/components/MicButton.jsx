import React from 'react';

export default function MicButton({ isListening, isSupported, onToggle, interimText }) {
  if (!isSupported) {
    return (
      <div className="mic-section">
        <div className="mic-unsupported">
          ⚠️ Speech Recognition is not supported in this browser.<br />
          Please use Chrome, Edge, or Safari.
        </div>
      </div>
    );
  }

  return (
    <div className="mic-section">
      <button
        id="mic-button"
        className={`mic-btn ${isListening ? 'mic-btn--listening' : ''}`}
        onClick={onToggle}
        aria-label={isListening ? 'Stop listening' : 'Start listening'}
      >
        {isListening ? '⏸' : '🎤'}
      </button>
      <div className="mic-label">
        {isListening ? (
          <><strong>Listening...</strong><br />Speak a command</>
        ) : (
          <><strong>Tap to Speak</strong><br />Say items to add to bill</>
        )}
      </div>
      <div className={`transcript ${isListening ? 'transcript--active' : ''}`}>
        {interimText ? (
          <span className="transcript__interim">🎙 {interimText}</span>
        ) : (
          isListening ? 'Waiting for speech...' : 'Voice commands will appear here'
        )}
      </div>
    </div>
  );
}

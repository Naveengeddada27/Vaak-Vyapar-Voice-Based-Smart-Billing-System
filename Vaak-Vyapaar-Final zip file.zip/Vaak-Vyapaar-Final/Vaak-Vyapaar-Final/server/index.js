import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import db from './database.js';

const app = express();
app.use(cors());
app.use(express.json());

// Simple token store (in-memory for prototype)
const sessions = new Map();

// Auth middleware
function auth(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token || !sessions.has(token)) return res.status(401).json({ error: 'Unauthorized' });
  req.user = sessions.get(token);
  next();
}

// ── Auth Routes ──
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  const token = uuidv4();
  sessions.set(token, { id: user.id, username: user.username, name: user.name, role: user.role });
  res.json({ token, user: { id: user.id, username: user.username, name: user.name, role: user.role } });
});

app.post('/api/logout', auth, (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  sessions.delete(token);
  res.json({ ok: true });
});

app.get('/api/me', auth, (req, res) => {
  res.json({ user: req.user });
});

// ── Product Routes ──
app.get('/api/products', auth, (req, res) => {
  const products = db.prepare('SELECT * FROM products WHERE active = 1 ORDER BY name').all();
  res.json(products.map(p => ({ ...p, aliases: JSON.parse(p.aliases) })));
});

app.post('/api/products', auth, (req, res) => {
  const { name, price, category, unit, aliases } = req.body;
  if (!name || !price) return res.status(400).json({ error: 'Name and price required' });
  const aliasArr = aliases || [name.toLowerCase()];
  const result = db.prepare('INSERT INTO products (name, aliases, price, category, unit) VALUES (?, ?, ?, ?, ?)')
    .run(name, JSON.stringify(aliasArr), price, category || 'General', unit || 'piece');
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(result.lastInsertRowid);
  res.json({ ...product, aliases: JSON.parse(product.aliases) });
});

app.put('/api/products/:id', auth, (req, res) => {
  const { name, price, category, unit, aliases } = req.body;
  db.prepare('UPDATE products SET name=?, aliases=?, price=?, category=?, unit=? WHERE id=?')
    .run(name, JSON.stringify(aliases || []), price, category, unit, req.params.id);
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  res.json({ ...product, aliases: JSON.parse(product.aliases) });
});

app.delete('/api/products/:id', auth, (req, res) => {
  db.prepare('UPDATE products SET active = 0 WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ── Bill Routes ──
app.post('/api/bills', auth, (req, res) => {
  const { invoice_no, items, subtotal, tax, total } = req.body;
  const result = db.prepare('INSERT INTO bills (invoice_no, user_id, items, subtotal, tax, total) VALUES (?, ?, ?, ?, ?, ?)')
    .run(invoice_no, req.user.id, JSON.stringify(items), subtotal, tax, total);
  res.json({ id: result.lastInsertRowid, invoice_no });
});

app.get('/api/bills', auth, (req, res) => {
  const bills = db.prepare('SELECT b.*, u.name as cashier FROM bills b LEFT JOIN users u ON b.user_id = u.id ORDER BY b.created_at DESC LIMIT 50').all();
  res.json(bills.map(b => ({ ...b, items: JSON.parse(b.items) })));
});

const PORT = 3001;
app.listen(PORT, () => console.log(`✅ Vaak Vyapaar API running on http://localhost:${PORT}`));

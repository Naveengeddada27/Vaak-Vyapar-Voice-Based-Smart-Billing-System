import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import bcrypt from 'bcryptjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const db = new DatabaseSync(join(__dirname, 'vaak.db'));

// Enable WAL mode for better performance
db.exec('PRAGMA journal_mode = WAL;');

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT DEFAULT 'cashier',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    aliases TEXT DEFAULT '[]',
    price REAL NOT NULL,
    category TEXT DEFAULT 'General',
    unit TEXT DEFAULT 'piece',
    active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS bills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_no TEXT UNIQUE NOT NULL,
    user_id INTEGER,
    items TEXT NOT NULL,
    subtotal REAL NOT NULL,
    tax REAL NOT NULL,
    total REAL NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
`);

// Seed default admin user if no users exist
const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get();
if (userCount.count === 0) {
  const hash = bcrypt.hashSync('admin123', 10);
  db.prepare('INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)').run('admin', hash, 'Admin', 'admin');
  const hash2 = bcrypt.hashSync('shop123', 10);
  db.prepare('INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)').run('shopkeeper', hash2, 'Shopkeeper', 'cashier');
}

// Seed default products if none exist
const prodCount = db.prepare('SELECT COUNT(*) as count FROM products').get();
if (prodCount.count === 0) {
  const products = [
    ['Milk', '["milk","doodh","milk packet","milk packets"]', 25, 'Dairy', 'packet'],
    ['Bread', '["bread","pav","bread loaf"]', 40, 'Bakery', 'piece'],
    ['Biscuit', '["biscuit","biscuits","cookie","cookies"]', 10, 'Snacks', 'packet'],
    ['Rice', '["rice","chawal","rice bag"]', 60, 'Grains', 'kg'],
    ['Sugar', '["sugar","cheeni","shakkar"]', 45, 'Grains', 'kg'],
    ['Tea', '["tea","chai","tea packet","tea powder"]', 20, 'Beverages', 'packet'],
    ['Coffee', '["coffee","coffee powder"]', 30, 'Beverages', 'packet'],
    ['Oil', '["oil","tel","cooking oil","refined oil"]', 120, 'Cooking', 'litre'],
    ['Dal', '["dal","daal","lentil","lentils","toor dal"]', 80, 'Grains', 'kg'],
    ['Soap', '["soap","sabun","bath soap"]', 35, 'Personal', 'piece'],
    ['Shampoo', '["shampoo"]', 90, 'Personal', 'bottle'],
    ['Toothpaste', '["toothpaste","paste","tooth paste"]', 50, 'Personal', 'piece'],
    ['Butter', '["butter","makhan"]', 55, 'Dairy', 'packet'],
    ['Cheese', '["cheese","paneer slice","cheese slice"]', 70, 'Dairy', 'packet'],
    ['Eggs', '["egg","eggs","anda","ande"]', 8, 'Dairy', 'piece'],
    ['Chips', '["chips","potato chips","crisps","wafers"]', 20, 'Snacks', 'packet'],
    ['Juice', '["juice","fruit juice"]', 30, 'Beverages', 'packet'],
    ['Water', '["water","paani","water bottle","mineral water"]', 15, 'Beverages', 'bottle'],
    ['Salt', '["salt","namak"]', 20, 'Cooking', 'kg'],
    ['Flour', '["flour","atta","wheat flour","maida"]', 45, 'Grains', 'kg'],
    ['Maggi', '["maggi","noodles","instant noodles"]', 14, 'Snacks', 'packet'],
    ['Curd', '["curd","dahi","yogurt","yoghurt"]', 30, 'Dairy', 'packet'],
    ['Ghee', '["ghee","desi ghee","clarified butter"]', 250, 'Cooking', 'litre'],
    ['Detergent', '["detergent","washing powder","surf","tide"]', 65, 'Household', 'packet'],
    ['Matchbox', '["matchbox","match box","matches"]', 5, 'Household', 'piece'],
  ];
  const insert = db.prepare('INSERT INTO products (name, aliases, price, category, unit) VALUES (?, ?, ?, ?, ?)');
  
  // node:sqlite doesn't have .transaction() like better-sqlite3
  // we do it manually
  db.exec('BEGIN TRANSACTION');
  try {
    for (const item of products) {
      insert.run(...item);
    }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

export default db;
